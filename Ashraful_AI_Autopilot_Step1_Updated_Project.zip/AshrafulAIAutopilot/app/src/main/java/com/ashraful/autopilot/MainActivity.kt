package com.ashraful.autopilot

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090D16)
private val Panel = Color(0xFF141C2B)
private val Blue = Color(0xFF3185FF)
private val Muted = Color(0xFF9AA8BD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AutopilotApp() }
    }
}

@Composable
fun AutopilotApp() {
    var selected by remember { mutableStateOf("Home") }
    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Blue, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    listOf("Home" to Icons.Default.Home, "Create" to Icons.Default.AutoAwesome,
                        "Schedule" to Icons.Default.CalendarMonth, "Settings" to Icons.Default.Settings).forEach { (label, icon) ->
                        NavigationBarItem(selected = selected == label, onClick = { selected = label },
                            icon = { Icon(icon, contentDescription = label) }, label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Blue, indicatorColor = Blue.copy(alpha = .18f), selectedTextColor = Blue, unselectedTextColor = Muted))
                    }
                }
            }
        ) { padding ->
            when (selected) {
                "Create" -> CreateScreen(Modifier.padding(padding))
                "Home" -> HomeScreen(Modifier.padding(padding), onCreate = { selected = "Create" })
                "Schedule" -> InfoScreen(Modifier.padding(padding), "Publishing Scheduler", "Scheduling is not connected yet. Social account authorization and a secure publishing backend are required before posts can be published.")
                else -> InfoScreen(Modifier.padding(padding), "Settings", "AI provider and social account settings will be added in a later update. Never enter API secrets into a public repository.")
            }
        }
    }
}

@Composable
private fun HomeScreen(modifier: Modifier = Modifier, onCreate: () -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Spacer(Modifier.height(12.dp)); Header() }
        item { SummaryCard() }
        item { Text("Automation workspace", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        item { FeatureCard(Icons.Default.AutoAwesome, "AI Content Generator", "Generate ideas, scripts and Flow prompts", "Open content tools", onCreate) }
        item { FeatureCard(Icons.Default.Movie, "Video Editing", "Prepare vertical videos, captions and exports", "Not connected yet") }
        item { FeatureCard(Icons.Default.Schedule, "Publishing Scheduler", "Plan 20 unique videos across 3 platforms", "Connect accounts to enable") }
        item { Text("Connected platforms", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        item { PlatformRow("Instagram", "Creator account", "Not connected", Icons.Default.CameraAlt) }
        item { PlatformRow("Facebook", "Page publishing", "Not connected", Icons.Default.Facebook) }
        item { PlatformRow("YouTube", "Shorts publishing", "Not connected", Icons.Default.PlayCircle) }
        item { Text("Version 1.1 • Content tools use on-device templates. Live AI, editing and publishing require secure API setup.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(vertical = 12.dp)) }
    }
}

@Composable
private fun CreateScreen(modifier: Modifier = Modifier) {
    var topic by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf("Video Script") }
    var result by remember { mutableStateOf("") }
    val options = listOf("Video Script", "Caption", "Flow AI Prompt", "Voice-over", "Hashtags")
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Spacer(Modifier.height(18.dp)); Text("AI CONTENT GENERATOR", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold); Text("Create content drafts for your next video", color = Muted, fontSize = 13.sp) }
        item {
            Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Choose a tool", color = Color.White, fontWeight = FontWeight.Bold)
                    options.forEach { option ->
                        Row(Modifier.fillMaxWidth().clickable { kind = option }.background(if (kind == option) Blue.copy(alpha = .16f) else Color.Transparent, RoundedCornerShape(10.dp)).padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = kind == option, onClick = { kind = option }, colors = RadioButtonDefaults.colors(selectedColor = Blue))
                            Text(option, color = Color.White, modifier = Modifier.padding(start = 8.dp))
                        }
                    }
                    OutlinedTextField(value = topic, onValueChange = { topic = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Enter your video topic") }, placeholder = { Text("Example: Never give up on your dreams") }, minLines = 2, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Blue, unfocusedBorderColor = Muted, focusedLabelColor = Blue, unfocusedLabelColor = Muted))
                    Button(onClick = { result = makeDraft(kind, topic) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Blue), shape = RoundedCornerShape(12.dp)) { Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(8.dp)); Text("Generate draft") }
                }
            }
        }
        if (result.isNotBlank()) item {
            Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("YOUR DRAFT", color = Blue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text(result, color = Color.White, fontSize = 14.sp, lineHeight = 21.sp)
                    Text("This is an offline template draft, not live AI-generated content.", color = Muted, fontSize = 11.sp)
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

private fun makeDraft(kind: String, rawTopic: String): String {
    val topic = rawTopic.trim().ifBlank { "your chosen topic" }
    return when (kind) {
        "Video Script" -> "TITLE: $topic\n\nHOOK (0–3 sec): Have you ever thought about $topic?\n\nMAIN (3–25 sec): Share one useful idea about $topic. Explain why it matters, give a simple real-life example, and keep each sentence short.\n\nENDING: What do you think? Follow for more videos!"
        "Caption" -> "A little reminder about $topic. ✨\nStay focused, keep learning, and take one small step today.\nWhat is your experience? Share it below!"
        "Flow AI Prompt" -> "Create a realistic vertical 9:16 video about $topic. Use a natural real-life environment, cinematic but believable lighting, clear subject framing, smooth camera movement, and realistic details. Keep the scene consistent throughout. Do not add logos, watermarks, or on-screen text."
        "Voice-over" -> "[Warm, engaging voice]\nToday, let's talk about $topic. Sometimes the smallest lesson can make the biggest difference. Take a moment, think about how this applies to your life, and choose one positive action you can take today."
        else -> "#${topic.replace(Regex("[^A-Za-z0-9]+"), "").ifBlank { "Video" }} #ContentCreator #ShortVideo #DailyInspiration #LearnSomething #NewVideo"
    }
}

@Composable
private fun InfoScreen(modifier: Modifier, title: String, message: String) {
    Column(modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Spacer(Modifier.height(18.dp)); Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) { Text(message, color = Muted, modifier = Modifier.padding(18.dp), lineHeight = 22.sp) }
    }
}

@Composable
private fun Header() {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column { Text("ASHRAFUL", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold); Text("AI AUTOPILOT", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp) }
        Surface(shape = RoundedCornerShape(50), color = Blue.copy(alpha = .15f)) { Text("PERSONAL APP", color = Blue, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) }
    }
}

@Composable
private fun SummaryCard() {
    Surface(shape = RoundedCornerShape(22.dp), color = Panel, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Daily publishing target", color = Muted, fontSize = 13.sp)
            Row(verticalAlignment = Alignment.Bottom) { Text("20", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold); Text(" unique videos / day", color = Muted, modifier = Modifier.padding(bottom = 7.dp)) }
            LinearProgressIndicator(progress = { 0f }, modifier = Modifier.fillMaxWidth(), color = Blue, trackColor = Color(0xFF29364B))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("3 platforms", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold); Text("60 publishing actions planned", color = Muted, fontSize = 11.sp) }
        }
    }
}

@Composable
private fun FeatureCard(icon: ImageVector, title: String, description: String, status: String, onClick: (() -> Unit)? = null) {
    Surface(shape = RoundedCornerShape(18.dp), color = Panel, modifier = Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(12.dp), color = Blue.copy(alpha = .16f)) { Icon(icon, null, tint = Blue, modifier = Modifier.padding(12.dp).size(23.dp)) }
            Column(Modifier.weight(1f).padding(start = 12.dp)) { Text(title, color = Color.White, fontWeight = FontWeight.Bold); Text(description, color = Muted, fontSize = 12.sp); Text(status, color = Blue, fontSize = 11.sp, modifier = Modifier.padding(top = 5.dp)) }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

@Composable
private fun PlatformRow(name: String, detail: String, status: String, icon: ImageVector) {
    Surface(shape = RoundedCornerShape(16.dp), color = Panel, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(26.dp))
            Column(Modifier.weight(1f).padding(start = 12.dp)) { Text(name, color = Color.White, fontWeight = FontWeight.SemiBold); Text(detail, color = Muted, fontSize = 11.sp) }
            Text(status, color = Muted, fontSize = 11.sp)
        }
    }
}
